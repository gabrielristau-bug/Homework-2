#Questão 3

#média = 62 °C
#Desvio padrão = 3.5 °C
#T~N(62, 3.5^2)
#Item 1 que pe gerar variáveis Uniformes(0,1)

U1 <- runif(1)
U2 <- runif(1)

U1
U2

#Item 2
# Fórmulas que irei utilizar:
# Z1 = sqrt(-2 ln(U1)) * cos(2 pi U2)
# Z2 = sqrt(-2 ln(U1)) * sin(2 pi U2), sendo que Z1 e Z2 são independentes e seguem N(0,1)

Z1 <- sqrt(-2 * log(U1)) * cos(2 * pi * U2)
Z2 <- sqrt(-2 * log(U1)) * sin(2 * pi * U2)

Z1
Z2

Z <- c(Z1, Z2)
Z

#Item 3 Conversão para a distribuição da temperatura da CPU
#Transformação: T = 62 + 3.5 * Z

media <- 62
desvio_padrao <- 3.5

T <- media + desvio_padrao * Z
T
n <- 1000              # número de medições simuladas

set.seed(123)

box_muller <- function(n) {
  
  # Garante número par
  if (n %% 2 != 0) {
    n <- n + 1
  }
  
  U1 <- runif(n / 2)
  U2 <- runif(n / 2)
  
  Z1 <- sqrt(-2 * log(U1)) * cos(2 * pi * U2)
  Z2 <- sqrt(-2 * log(U1)) * sin(2 * pi * U2)
  
  Z <- c(Z1, Z2)
  return(Z)
}

#Gerando duas observações (exemplo da Parte 1)
Z_exemplo <- box_muller(2)
T_exemplo <- media + desvio_padrao * Z_exemplo

Z_exemplo
T_exemplo

#Conjunto 1: usando Box-Muller
Z_bm <- box_muller(n)
T_bm <- media + desvio_padrao * Z_bm

#Conjunto 2: usando RNG nativo do R
T_rnorm <- rnorm(n, mean = media, sd = desvio_padrao)

#Item 3

#a) Média amostral
mean(T_bm)
mean(T_rnorm)

#b) Desvio padrão amostral
sd(T_bm)
sd(T_rnorm)

#c) Valores mínimo e máximo observados
min(T_bm); max(T_bm)
min(T_rnorm); max(T_rnorm)

#d) Probabilidade empírica e teórica: P(T > 68)

# Empírica
mean(T_bm > 68)
mean(T_rnorm > 68)

#Teórica
1 - pnorm(68, mean = media, sd = desvio_padrao)

#e) Probabilidade empírica e teórica: P(60 < T < 65)

#Empírica
mean(T_bm > 60 & T_bm < 65)
mean(T_rnorm > 60 & T_rnorm < 65)

#Teórica
pnorm(65, mean = media, sd = desvio_padrao) -
  pnorm(60, mean = media, sd = desvio_padrao)

#f) Probabilidade teórica: P(T > 75)

1 - pnorm(75, mean = media, sd = desvio_padrao)

# Observação:
# Eventos acima de 75°C são extremamente raros e dificilmente
# aparecem em apenas 1.000 simulações.

#Item 4

#a) Histogramas das temperaturas simuladas

hist(T_bm, probability = TRUE,
     main = "Temperaturas da CPU – Box-Muller",
     xlab = "Temperatura (°C)",
     col = "lightgray",
     border = "white")

hist(T_rnorm, probability = TRUE,
     main = "Temperaturas da CPU – rnorm()",
     xlab = "Temperatura (°C)",
     col = "lightblue",
     border = "white")

#b) Curva normal teórica sobreposta (Box-Muller)

hist(T_bm, probability = TRUE,
     main = "Box-Muller vs Normal Teórica",
     xlab = "Temperatura (°C)",
     col = "lightgray",
     border = "white")

curve(dnorm(x, mean = media, sd = desvio_padrao),
      col = "red",
      lwd = 2,
      add = TRUE)

#Item 5
#As distribuições empíricas se aproximam bem da Normal teórica
#Médias e desvios padrão amostrais são próximos aos valores esperados
#Box-Muller e rnorm produzem resultados estatisticamente equivalentes
#Diferenças pequenas são explicadas pela variabilidade amostral
#Simulações ajudam a estudar eventos extremos e estratégias de resfriamento


#Questão 1
n <- 50 #número de clientes
p <- 0.7 #probabilidade de um cliente pedir sobremesa

#Item 1
#Como a distribuição de X é Binomial.A função massa de probabilidade é dada por:
#Nisso fica P(X = x) = C(50, x) * (0.7)^x * (0.3)^(50 - x)
x <- 0:n

#Item 2
#Resolver a PMF e a CDF
pmf <- dbinom(x, size = n, prob = p)
plot(x, pmf, type = "h",
     main = "PMF de X~Binomial(50, 0.7)",
     xlab = "Número de clientes que pedem a sobremesa",
     ylab = "Probabilidade:")
cdf <- pbinom(x, size = n, prob = p)
plot(x, cdf, type = "s",
     main = "CDF de X~Binomial(50, 0.7)",
     xlab = "Número de clientes que pedem a sobremesa",
     ylab = "P(X ≤ x)")

#Item 3,que vai gerar o Valor esperado, variância e desvio padrão
esperanca <- n * p
variancia <- n * p * (1 - p)
desvio_padrao <- sqrt(variancia) #aqui utilizei as formulas normais deles

esperanca
variancia
desvio_padrao

#Item 4 que gerará o cálculo de probabilidades
#a) P(X ≥ 20)
prob_a <- 1 - pbinom(19, size = n, prob = p)
prob_a
#b) P(30 < X < 43) = P(31 ≤ X ≤ 42)
prob_b <- pbinom(42, size = n, prob = p) -
  pbinom(30, size = n, prob = p)
prob_b
#c) P(X = 31)
prob_c <- dbinom(31, size = n, prob = p)
prob_c

#Item 5 Aplicação prática: estoque de sobremesas
#O valor esperado indica que terei 35 clientes, em média, pedem sobremesa. O restaurante pode usar a distribuição para planejar o estoque e evitar desperdício ou falta.
#Quantidade de sobremesas para atender 95% da demanda
estoque_95 <- qbinom(0.95, size = n, prob = p) #0.95 dos 95%
estoque_95

#Item 6 Impacto de mudanças em p e n
p_novo <- 0.8
pmf_p08 <- dbinom(x, size = n, prob = p_novo)

plot(x, pmf_p08, type = "h",
     main = "PMF de X~Binomial(50, 0.8)",
     xlab = "Número de clientes que pedem a sobremesa",
     ylab = "Probabilidade")

n_novo <- 100
x2 <- 0:n_novo
pmf_n100 <- dbinom(x2, size = n_novo, prob = p)

plot(x2, pmf_n100, type = "h",
     main = "PMF de X~Binomial(100, 0.7)",
     xlab = "Número de clientes que pedem a sobremesa",
     ylab = "Probabilidade")


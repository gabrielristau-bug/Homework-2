#Questão 2
#Aqui está os parametros que preciso para esse exercicio 2

n <- 1e7      #número de visitantes por dia
p <- 1e-7     #probabilidade de um visitante ganhar a recompensa

#Aqui é a formula X~Binomial(n = 10^7, p = 10^-7)
#Item 1
lambda <- n * p   # parâmetro da Poisson
lambda
#Logo: X ≈ Poisson(lambda = 1)
#Item 2
#Distribuição Binomial
E_bin <- n*p
Var_bin <- n *p*(1 - p)

#Distribuição Poisson
E_pois <- lambda
Var_pois <- lambda

E_bin
Var_bin
E_pois
Var_pois

#Item 3
# E[1 / (W + 1)]
w <- 0:20
prob_ganhar <- sum((1 / (w + 1)) * dpois(w, lambda = 1))
prob_ganhar

#Item 4
set.seed(123)
dias <- 100000   #n de dias simulados
#Simulação do número de vencedores por dia
X_sim <- rpois(dias, lambda = 1)

#Frequências empíricas
freq_emp <- table(X_sim) / dias

#Valores teóricos da Poisson(1)
x <- 0:6
pmf_pois <- dpois(x, lambda = 1)

#Comparação visual
barplot(freq_emp[x + 1],
        names.arg = x,
        ylim = c(0, max(freq_emp, pmf_pois)),
        main = "Simulação vs Poisson(1)",
        ylab = "Probabilidade")

points(x + 0.5, pmf_pois, pch = 19)
legend("topright",
       legend = c("Simulação", "Poisson(1)"),
       pch = c(15, 19))

